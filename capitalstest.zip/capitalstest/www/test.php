<?php
	setcookie("name", $_POST["name"], time()+3600); 
?>
<html>
	<head>
		<title>Test</title>
	</head>
	<body>
		<?php
			echo "User: ".$_POST["name"];
		?>
		<h1 align=center>Test</h1>
		<form name=test action=result.php method=POST>
			<p>The capital of Estonia:</p>
			<p>
				<input type="radio" name="cap1" value="res1"> Vilnius<br>
				<input type="radio" name="cap1" value="res2"> Tallinn<br>
				<input type="radio" name="cap1" value="res3"> Riga<br>
			</p>
			<p>The capital of Ireland:</p>
			<p>
				<input type="radio" name="cap2" value="res1"> Edinburgh<br>
				<input type="radio" name="cap2" value="res2"> London<br>
				<input type="radio" name="cap2" value="res3"> Dublin<br>
			</p>
			<p>The capital of Austria:</p>
			<p>
				<input type="radio" name="cap3" value="res1"> Bern<br>
				<input type="radio" name="cap3" value="res2"> Vienna<br>
				<input type="radio" name="cap3" value="res3"> Salzburg<br>
			</p>
			<p>The capital of Mexico:</p>
			<p>
				<input type="radio" name="cap4" value="res1"> Acapulco<br>
				<input type="radio" name="cap4" value="res2"> Mexico<br>
				<input type="radio" name="cap4" value="res3"> Tijuana<br>
			</p>
			<p>The capital of Lithania:</p>
			<p>
				<input type="radio" name="cap5" value="res1"> Vilnius<br>
				<input type="radio" name="cap5" value="res2"> Tallinn<br>
				<input type="radio" name="cap5" value="res3"> Riga<br>
			</p>
			<p>The capital of Netherlands:</p>
			<p>
				<input type="radio" name="cap6" value="res1"> Rotterdam<br>
				<input type="radio" name="cap6" value="res2"> Amsterdam<br>
				<input type="radio" name="cap6" value="res3"> Utrecht<br>
			</p>
			<p>The capital of Germany:</p>
			<p>
				<input type="radio" name="cap7" value="res1"> Munich<br>
				<input type="radio" name="cap7" value="res2"> Berlin<br>
				<input type="radio" name="cap7" value="res3"> Frankfurt am Main<br>
			</p>
			<p>The capital of UK:</p>
			<p>
				<input type="radio" name="cap8" value="res1"> London<br>
				<input type="radio" name="cap8" value="res2"> Edinburgh<br>
				<input type="radio" name="cap8" value="res3"> Wales<br>
			</p>
			<p>The capital of Iceland:</p>
			<p>
				<input type="radio" name="cap9" value="res1"> Akureyri<br>
				<input type="radio" name="cap9" value="res2"> Reykjavik<br>
				<input type="radio" name="cap9" value="res3"> Kopavogur<br>
			</p>
			<p>The capital of Spain:</p>
			<p>
				<input type="radio" name="cap10" value="res1"> Madrid<br>
				<input type="radio" name="cap10" value="res2"> Valencia<br>
				<input type="radio" name="cap10" value="res3"> Barcelona<br>
			</p>
			<input type="submit" name="but2" value="Submit">
		</form>
	</body>
</html>