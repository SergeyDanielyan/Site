<html>
	<head>
		<title>Result</title>
	</head>
	<body>
		<h1 align=center>Result</h1>
		<?php
			$res = 0;
			if ($_POST['cap1'] == "res2") {
				$res++;
			}
			if ($_POST['cap2'] == "res3") {
				$res++;
			}
			if ($_POST['cap3'] == "res2") {
				$res++;
			}
			if ($_POST['cap4'] == "res2") {
				$res++;
			}
			if ($_POST['cap5'] == "res1") {
				$res++;
			}
			if ($_POST['cap6'] == "res2") {
				$res++;
			}
			if ($_POST['cap7'] == "res2") {
				$res++;
			}
			if ($_POST['cap8'] == "res1") {
				$res++;
			}
			if ($_POST['cap9'] == "res2") {
				$res++;
			}
			if ($_POST['cap10'] == "res1") {
				$res++;
			}
			echo $_COOKIE['name'].", your result: ".$res."<br>";
			$mysqli = new mysqli("localhost", "SergeyDanielyan", "rfQrBSHLCQHKFwbt", "capitalstest");
			if ($mysqli->connect_errno) {
				printf("Не удалось подключиться: %s\n", $mysqli->connect_error);
				exit();
			}
			$name = $_COOKIE['name'];
			if ($mysqli->query("INSERT INTO results (name, result) VALUES ('$name', '$res')") == true){
				echo "Your result included in the general list."."<br>";
			}
			$result = $mysqli->query("SELECT name, result FROM results ORDER BY result DESC");
			echo "Best results:";
			echo "<table border='1' width='100%' cellpadding='5'>
				<tr>
					<th>Name</th>
					<th>Result</th>
				</tr>";
				while ($myrow = mysqli_fetch_array($result)) {
					$n = $myrow['name'];
					$r = $myrow['result'];
					echo "<tr>
						<td>$n</td>
						<td>$r</td>
					</tr>";
				}
			echo "</table>";
		?>
	</body>
</html>